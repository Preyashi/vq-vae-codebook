"""
model/vqvae_model.py

Three complete models sharing the same WorkflowEncoder:

  MLPResiliencyModel          (Phase 1)
    encoder → z → policy heads (continuous latent, no VQ)

  VQResiliencyModel           (Phase 2)
    encoder → z_e → VQCodebookEMA → z_q → policy heads
    Shared discrete latent; EMA updates prevent collapse.

  FactorizedVQResiliencyModel (Phase 3 / paper contribution)
    encoder → z_e → FactorizedVQCodebook → [z_q_r, z_q_t, z_q_c, z_q_f]
    Each policy head receives its own dimension-specific quantised vector.
    Collapse impossible: K_i == num_classes_i per dimension.
"""

from __future__ import annotations
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import List, Tuple

from .encoder      import WorkflowEncoder, LATENT_DIM
from .codebook     import VQCodebookEMA, FactorizedVQCodebook
from .policy_heads import PolicyHeads, PolicyPrediction, _Head
from ..trace_generator import FEATURE_DIM
from ..label_oracle    import POLICY_DIMS
from ..counterfactual_labeler import N_FAILURE_CATEGORIES, FAILURE_CATEGORY_NAMES


# ── Shared loss helper ────────────────────────────────────────────────────────

def _head_loss(r_l, t_l, c_l, f_l, labels: torch.Tensor) -> torch.Tensor:
    return (
        F.cross_entropy(r_l, labels[:, 0])
        + F.cross_entropy(t_l, labels[:, 1])
        + F.cross_entropy(c_l, labels[:, 2])
        + F.cross_entropy(f_l, labels[:, 3])
    )


# ── Phase 1: MLP baseline ─────────────────────────────────────────────────────

class MLPResiliencyModel(nn.Module):
    """Encoder → continuous z → policy heads.  No codebook."""

    def __init__(self, feature_dim: int = FEATURE_DIM, latent_dim: int = LATENT_DIM):
        super().__init__()
        self.encoder = WorkflowEncoder(feature_dim, latent_dim)
        self.heads   = PolicyHeads(latent_dim)

    def forward(self, x: torch.Tensor) -> Tuple:
        z = self.encoder(x)
        return self.heads(z)

    def loss(self, x: torch.Tensor, labels: torch.Tensor) -> torch.Tensor:
        return _head_loss(*self.forward(x), labels)

    def predict(self, x: torch.Tensor) -> PolicyPrediction:
        z = self.encoder(x)
        return self.heads.predict(z)

    def get_logits(self, x: torch.Tensor) -> Tuple:
        return self.forward(x)


# ── Phase 2: Shared VQ-VAE with EMA codebook ─────────────────────────────────

class VQResiliencyModel(nn.Module):
    """
    Encoder → z_e → VQCodebookEMA → z_q → policy heads.

    Uses EMA codebook updates (not gradient-based) and dead-code restart
    to prevent the collapse seen with VQCodebookGrad.
    """

    def __init__(
        self,
        feature_dim:       int   = FEATURE_DIM,
        latent_dim:        int   = LATENT_DIM,
        codebook_size:     int   = 16,
        vq_beta:           float = 0.25,
        ema_decay:         float = 0.99,
        restart_threshold: float = 1.0,
    ):
        super().__init__()
        self.encoder  = WorkflowEncoder(feature_dim, latent_dim)
        self.codebook = VQCodebookEMA(
            codebook_size, latent_dim, vq_beta, ema_decay, restart_threshold
        )
        self.heads = PolicyHeads(latent_dim)

    def forward(self, x: torch.Tensor) -> Tuple:
        """Returns (r_l, t_l, c_l, f_l, code_idx, vq_loss)."""
        z_e                    = self.encoder(x)
        z_q, code_idx, vq_loss = self.codebook(z_e)
        r_l, t_l, c_l, f_l    = self.heads(z_q)
        return r_l, t_l, c_l, f_l, code_idx, vq_loss

    def loss(self, x: torch.Tensor, labels: torch.Tensor) -> Tuple[torch.Tensor, dict]:
        r_l, t_l, c_l, f_l, _, vq_loss = self.forward(x)
        task_loss  = _head_loss(r_l, t_l, c_l, f_l, labels)
        total_loss = task_loss + vq_loss
        return total_loss, {
            "task_loss":  task_loss.item(),
            "vq_loss":    vq_loss.item(),
            "perplexity": self.codebook.perplexity(),
        }

    def predict(self, x: torch.Tensor) -> PolicyPrediction:
        with torch.no_grad():
            z_e         = self.encoder(x)
            z_q, _, _   = self.codebook(z_e)
            return self.heads.predict(z_q)

    def get_logits(self, x: torch.Tensor) -> Tuple:
        r_l, t_l, c_l, f_l, _, _ = self.forward(x)
        return r_l, t_l, c_l, f_l

    def code_for(self, x: torch.Tensor) -> int:
        with torch.no_grad():
            z_e      = self.encoder(x.unsqueeze(0) if x.dim() == 1 else x)
            _, idx, _ = self.codebook(z_e)
            return int(idx[0].item())

    def load_encoder_from_mlp(self, mlp: MLPResiliencyModel) -> None:
        self.encoder.load_state_dict(mlp.encoder.state_dict())


# ── Phase 3: Factorized VQ-VAE (paper contribution) ──────────────────────────

class FactorizedVQResiliencyModel(nn.Module):
    """
    Encoder → z_e → FactorizedVQCodebook → per-dimension z_q → per-head logits.

    Each policy dimension gets its own VQ codebook whose K equals the
    number of classes for that dimension.  This means:

    - Collapse is structurally impossible (K entries for K classes).
    - Each codebook entry specialises in exactly one output class.
    - Dimensions are compositional: retry and circuit-breaker are quantised
      independently, so any combination can be expressed.

    The paper claim: factorized discrete latents produce better policy
    validity than a shared codebook because inconsistent cross-dimension
    assignments (e.g. CB:open + retry:2) cannot arise from a single
    prototype; each dimension votes independently.
    """

    def __init__(
        self,
        feature_dim:       int   = FEATURE_DIM,
        latent_dim:        int   = LATENT_DIM,
        policy_dims:       Tuple = POLICY_DIMS,   # (4, 3, 3, 4)
        vq_beta:           float = 0.25,
        ema_decay:         float = 0.99,
        restart_threshold: float = 1.0,
    ):
        super().__init__()
        self.encoder   = WorkflowEncoder(feature_dim, latent_dim)
        self.codebooks = FactorizedVQCodebook(
            latent_dim, policy_dims, vq_beta, ema_decay, restart_threshold
        )
        # Independent heads — each receives a different z_q
        self.retry_head    = _Head(latent_dim, policy_dims[0])
        self.timeout_head  = _Head(latent_dim, policy_dims[1])
        self.cb_head       = _Head(latent_dim, policy_dims[2])
        self.fallback_head = _Head(latent_dim, policy_dims[3])

    def forward(self, x: torch.Tensor) -> Tuple:
        """Returns (r_l, t_l, c_l, f_l, code_idxs_list, total_vq_loss)."""
        z_e                         = self.encoder(x)
        z_qs, code_idxs, total_vq   = self.codebooks(z_e)
        r_l = self.retry_head(z_qs[0])
        t_l = self.timeout_head(z_qs[1])
        c_l = self.cb_head(z_qs[2])
        f_l = self.fallback_head(z_qs[3])
        return r_l, t_l, c_l, f_l, code_idxs, total_vq

    def loss(self, x: torch.Tensor, labels: torch.Tensor) -> Tuple[torch.Tensor, dict]:
        r_l, t_l, c_l, f_l, _, vq_loss = self.forward(x)
        task_loss  = _head_loss(r_l, t_l, c_l, f_l, labels)
        total_loss = task_loss + vq_loss
        perps = self.codebooks.perplexities()
        return total_loss, {
            "task_loss":   task_loss.item(),
            "vq_loss":     vq_loss.item(),
            "perplexity":  self.codebooks.mean_perplexity(),
            "perp_per_dim": perps,
        }

    def predict(self, x: torch.Tensor) -> PolicyPrediction:
        with torch.no_grad():
            z_e              = self.encoder(x)
            z_qs, _, _       = self.codebooks(z_e)
            retry    = int(self.retry_head(z_qs[0]).argmax(1).item())
            timeout  = int(self.timeout_head(z_qs[1]).argmax(1).item())
            cb       = int(self.cb_head(z_qs[2]).argmax(1).item())
            fallback = int(self.fallback_head(z_qs[3]).argmax(1).item())
        return PolicyPrediction(retry, timeout, cb, fallback)

    def get_logits(self, x: torch.Tensor) -> Tuple:
        r_l, t_l, c_l, f_l, _, _ = self.forward(x)
        return r_l, t_l, c_l, f_l

    def codes_for(self, x: torch.Tensor) -> List[int]:
        """Return the code index for each dimension for a single context vector."""
        with torch.no_grad():
            z_e          = self.encoder(x.unsqueeze(0) if x.dim() == 1 else x)
            _, idxs, _   = self.codebooks(z_e)
            return [int(idx[0].item()) for idx in idxs]

    def load_encoder_from_mlp(self, mlp: MLPResiliencyModel) -> None:
        self.encoder.load_state_dict(mlp.encoder.state_dict())


# ── Phase 4: Temporal Factorized VQ with hierarchical decoder (oracle-free) ───

class TemporalVQResiliencyModel(nn.Module):
    """
    Factorized VQ trained on 47-dim input (38 static + 9 temporal observables
    including CB-state feedback) with counterfactual simulation labels.

    Hierarchical decoder:
      Level 1 — category_head predicts failure category first
                 (NOMINAL / TRANSIENT / PERSISTENT / TRANSACTION)
      Level 2 — four policy heads decode the specific recovery action
                 (retry, timeout, CB setting, fallback)

    Both levels share the same codebook embedding, so the model learns
    "operational resilience states" that are interpretable at two levels:
    the category mirrors expert triage reasoning, the policy maps to
    well-established distributed-systems patterns.
    """

    def __init__(
        self,
        feature_dim:       int   = 47,
        latent_dim:        int   = LATENT_DIM,
        policy_dims:       tuple = POLICY_DIMS,
        vq_beta:           float = 0.25,
        ema_decay:         float = 0.99,
        restart_threshold: float = 1.0,
    ):
        super().__init__()
        self.encoder   = WorkflowEncoder(feature_dim, latent_dim)
        self.codebooks = FactorizedVQCodebook(
            latent_dim, policy_dims, vq_beta, ema_decay, restart_threshold
        )
        # Level 1: failure-category head (shared across all policy dims)
        self.category_head = _Head(latent_dim, N_FAILURE_CATEGORIES)
        # Level 2: per-dimension policy heads
        self.retry_head    = _Head(latent_dim, policy_dims[0])
        self.timeout_head  = _Head(latent_dim, policy_dims[1])
        self.cb_head       = _Head(latent_dim, policy_dims[2])
        self.fallback_head = _Head(latent_dim, policy_dims[3])

    def forward(self, x: torch.Tensor) -> tuple:
        z_e                        = self.encoder(x)
        z_qs, code_idxs, total_vq  = self.codebooks(z_e)
        # category head uses the first codebook's quantised vector (retry dim
        # has the highest perplexity and best separates scenario archetypes)
        cat_l = self.category_head(z_qs[0])
        r_l   = self.retry_head(z_qs[0])
        t_l   = self.timeout_head(z_qs[1])
        c_l   = self.cb_head(z_qs[2])
        f_l   = self.fallback_head(z_qs[3])
        return cat_l, r_l, t_l, c_l, f_l, code_idxs, total_vq

    def loss(self, x: torch.Tensor, labels: torch.Tensor) -> tuple:
        """
        labels shape: (B, 5) — columns: [retry, timeout, cb, fallback, category]
        """
        cat_l, r_l, t_l, c_l, f_l, _, vq_loss = self.forward(x)
        cat_loss  = F.cross_entropy(cat_l, labels[:, 4])
        task_loss = _head_loss(r_l, t_l, c_l, f_l, labels) + cat_loss
        return task_loss + vq_loss, {
            "task_loss":  task_loss.item(),
            "vq_loss":    vq_loss.item(),
            "perplexity": self.codebooks.mean_perplexity(),
        }

    def predict(self, x: torch.Tensor) -> PolicyPrediction:
        with torch.no_grad():
            z_e        = self.encoder(x)
            z_qs, _, _ = self.codebooks(z_e)
            category = int(self.category_head(z_qs[0]).argmax(1).item())
            retry    = int(self.retry_head(z_qs[0]).argmax(1).item())
            timeout  = int(self.timeout_head(z_qs[1]).argmax(1).item())
            cb       = int(self.cb_head(z_qs[2]).argmax(1).item())
            fallback = int(self.fallback_head(z_qs[3]).argmax(1).item())
        return PolicyPrediction(retry, timeout, cb, fallback, category=category)

    def get_logits(self, x: torch.Tensor) -> tuple:
        cat_l, r_l, t_l, c_l, f_l, _, _ = self.forward(x)
        return r_l, t_l, c_l, f_l

    def codes_for(self, x: torch.Tensor) -> List[int]:
        with torch.no_grad():
            z_e        = self.encoder(x.unsqueeze(0) if x.dim() == 1 else x)
            _, idxs, _ = self.codebooks(z_e)
            return [int(idx[0].item()) for idx in idxs]

    def category_accuracy(self, x: torch.Tensor, cat_labels: torch.Tensor) -> float:
        """Compute category-head accuracy over a batch."""
        with torch.no_grad():
            z_e        = self.encoder(x)
            z_qs, _, _ = self.codebooks(z_e)
            preds      = self.category_head(z_qs[0]).argmax(1)
        return float((preds == cat_labels).float().mean().item())
