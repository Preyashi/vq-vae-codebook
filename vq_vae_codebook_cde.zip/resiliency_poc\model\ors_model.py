"""
model/ors_model.py

Operational Resilience State (ORS) VQ-VAE.

Architecture (professor feedback, 2026-07-05):
  Input (47-dim)
    → WorkflowEncoder
    → ONE shared VQ codebook (K entries)
    → Operational Resilience State  ← the research contribution
    → PolicyHeads (retry | timeout | CB | fallback)

Key differences from the factorized model (ors_poc.py replaces poc.py):

1. ONE shared codebook, not one-per-policy-dimension.
   Each code entry represents an operational situation (e.g. "transient API
   congestion") rather than a policy prototype (e.g. "retry archetype").

2. Category head is NOT in the training loss.
   It is only used for post-hoc interpretability — the model discovers the
   category taxonomy without supervision, making it a verifiable claim
   rather than a trivially trained output.

3. All four policy heads decode from the same z_q.
   This forces the codebook to represent a shared operational context
   that is sufficient for all policy decisions simultaneously.

The ORS table (produced by ors_poc.py) answers:
  "What does each codebook entry represent?"
  Code | Scenario        | Avg latency | Avg fail-rate | Policy
  ---- | --------------- | ----------- | ------------- | ------
  ...
"""

from __future__ import annotations
from collections import Counter, defaultdict
from dataclasses import dataclass
from typing import Dict, List, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from .encoder      import WorkflowEncoder, LATENT_DIM
from .codebook     import VQCodebookEMA
from .policy_heads import PolicyHeads, PolicyPrediction
from ..counterfactual_labeler import FAILURE_CATEGORY_NAMES, SCENARIO_TO_CATEGORY
from ..scenario    import SCENARIO_NAMES


# ── ORS-VQ model ─────────────────────────────────────────────────────────────

class ORSVQModel(nn.Module):
    """
    One encoder → one shared VQ codebook → four policy heads.

    The codebook learns Operational Resilience States (ORS).
    Category prediction is post-hoc only (not trained).
    """

    def __init__(
        self,
        feature_dim:       int   = 47,
        latent_dim:        int   = LATENT_DIM,
        codebook_size:     int   = 16,
        vq_beta:           float = 0.25,
        ema_decay:         float = 0.99,
        restart_threshold: float = 1.0,
    ):
        super().__init__()
        self.codebook_size = codebook_size
        self.encoder  = WorkflowEncoder(feature_dim, latent_dim)
        self.codebook = VQCodebookEMA(codebook_size, latent_dim, vq_beta,
                                      ema_decay, restart_threshold)
        self.heads    = PolicyHeads(latent_dim)

    def forward(self, x: torch.Tensor) -> Tuple:
        """Returns (r_l, t_l, c_l, f_l, code_idx, vq_loss)."""
        z_e                    = self.encoder(x)
        z_q, code_idx, vq_loss = self.codebook(z_e)
        r_l, t_l, c_l, f_l    = self.heads(z_q)
        return r_l, t_l, c_l, f_l, code_idx, vq_loss

    def loss(self, x: torch.Tensor, labels: torch.Tensor) -> Tuple[torch.Tensor, dict]:
        """
        labels: (B, 4)  [retry, timeout, cb, fallback]
        Category is NOT in the loss — it is purely emergent.
        """
        r_l, t_l, c_l, f_l, _, vq_loss = self.forward(x)
        task_loss = (
            F.cross_entropy(r_l, labels[:, 0])
            + F.cross_entropy(t_l, labels[:, 1])
            + F.cross_entropy(c_l, labels[:, 2])
            + F.cross_entropy(f_l, labels[:, 3])
        )
        total = task_loss + vq_loss
        return total, {
            "task_loss":  task_loss.item(),
            "vq_loss":    vq_loss.item(),
            "perplexity": self.codebook.perplexity(),
        }

    def predict(self, x: torch.Tensor) -> PolicyPrediction:
        with torch.no_grad():
            z_e         = self.encoder(x)
            z_q, _, _   = self.codebook(z_e)
            return self.heads.predict(z_q)

    def get_logits(self, x: torch.Tensor) -> Tuple:
        r_l, t_l, c_l, f_l, _, _ = self.forward(x)
        return r_l, t_l, c_l, f_l

    def code_for(self, x: torch.Tensor) -> int:
        with torch.no_grad():
            z_e      = self.encoder(x.unsqueeze(0) if x.dim() == 1 else x)
            _, idx, _ = self.codebook(z_e)
            return int(idx[0].item())

    # ── ORS analysis helpers ──────────────────────────────────────────────────

    def collect_codes(self, events: list) -> np.ndarray:
        """Return code index for every event (preserves order)."""
        self.eval()
        codes = []
        with torch.no_grad():
            for ev in events:
                x = torch.tensor(ev.to_feature_vector(), dtype=torch.float32).unsqueeze(0)
                codes.append(self.code_for(x))
        return np.array(codes)

    def ors_table(self, events: list) -> List[dict]:
        """
        Build the Operational Resilience State table.

        For each active code entry, returns:
          code          — code index
          count         — number of events assigned
          top_scenario  — most common scenario name
          scenario_purity — fraction of events matching top scenario
          top_policy    — (retry, timeout, cb, fallback) most common prediction
          avg_fail_rate — mean rolling_failure_rate feature (index 38)
          avg_cb_open   — mean cb_is_open feature (index 43)
          avg_consec    — mean consecutive_failures feature (index 39)
          emergent_category — FAILURE_CATEGORY_NAMES[most common SCENARIO_TO_CATEGORY]
        """
        codes = self.collect_codes(events)
        self.eval()

        # Group events by code
        buckets: Dict[int, list] = defaultdict(list)
        for ev, c in zip(events, codes):
            buckets[c].append(ev)

        rows = []
        for code in sorted(buckets.keys()):
            evs = buckets[code]
            n   = len(evs)

            # Scenario distribution
            scenario_counts = Counter(ev.scenario for ev in evs)
            top_scenario    = scenario_counts.most_common(1)[0][0]
            purity          = scenario_counts[top_scenario] / n

            # Emergent category (post-hoc, not trained)
            cat_counts = Counter(
                SCENARIO_TO_CATEGORY.get(ev.scenario, 0) for ev in evs
            )
            top_cat_idx = cat_counts.most_common(1)[0][0]
            cat_purity  = cat_counts[top_cat_idx] / n

            # Temporal feature statistics (from to_feature_vector)
            feats = np.stack([ev.to_feature_vector() for ev in evs])
            # feature layout: [static(38) | rolling_failure_rate(38) | consec(39)
            #                  | time_in_scenario(40) | scenario_duration(41)
            #                  | degradation_slope(42) | cb_state(43) | cb_open(44)
            #                  | cb_trip_count(45) | scenario_age(46)]
            avg_fail_rate = float(feats[:, 38].mean())
            avg_consec    = float(feats[:, 39].mean())
            avg_cb_open   = float(feats[:, 44].mean())

            # Most common predicted policy
            with torch.no_grad():
                X    = torch.tensor(feats, dtype=torch.float32)
                r_l, t_l, c_l, f_l, _, _ = self.forward(X)
            top_retry    = int(r_l.argmax(1).mode().values.item())
            top_timeout  = int(t_l.argmax(1).mode().values.item())
            top_cb       = int(c_l.argmax(1).mode().values.item())
            top_fallback = int(f_l.argmax(1).mode().values.item())

            rows.append({
                "code":               code,
                "count":              n,
                "top_scenario":       SCENARIO_NAMES[int(top_scenario)],
                "scenario_purity":    purity,
                "emergent_category":  FAILURE_CATEGORY_NAMES[top_cat_idx],
                "cat_purity":         cat_purity,
                "avg_fail_rate":      avg_fail_rate,
                "avg_consec":         avg_consec,
                "avg_cb_open":        avg_cb_open,
                "top_policy":         (top_retry, top_timeout, top_cb, top_fallback),
            })
        return rows

    def cross_workflow_codes(self, events: list) -> Dict[str, Dict[str, Counter]]:
        """
        For each (workflow, scenario) pair, count which ORS codes fire.
        Returns: {workflow_name: {scenario_name: Counter(code → count)}}
        Used to demonstrate transfer: same scenario in different workflows
        activates the same ORS code.
        """
        codes  = self.collect_codes(events)
        result: Dict[str, Dict[str, Counter]] = defaultdict(lambda: defaultdict(Counter))
        for ev, c in zip(events, codes):
            wf  = ev.workflow_name
            sc  = SCENARIO_NAMES[int(ev.scenario)]
            result[wf][sc][c] += 1
        return result
