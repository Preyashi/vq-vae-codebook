"""
model/encoder.py

Shared workflow-context encoder used by both the Phase-1 MLP and the
Phase-2 VQ-VAE.  Kept separate so Phase 2 can load Phase-1 weights.
"""

from __future__ import annotations
import torch
import torch.nn as nn

from ..trace_generator import FEATURE_DIM

LATENT_DIM = 32


class WorkflowEncoder(nn.Module):
    """
    Maps a flat context feature vector (FEATURE_DIM=38) to a continuous
    latent vector z ∈ ℝ^LATENT_DIM.
    """

    def __init__(self, feature_dim: int = FEATURE_DIM, latent_dim: int = LATENT_DIM):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(feature_dim, 64),
            nn.ReLU(),
            nn.LayerNorm(64),
            nn.Linear(64, latent_dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)
