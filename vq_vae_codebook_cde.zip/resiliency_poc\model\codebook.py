"""
model/codebook.py

Three codebook classes, each a step up from the previous:

  VQCodebookGrad   (original / baseline)
    Gradient-based embedding updates.  Prone to collapse because popular
    entries dominate and dead entries receive no gradient signal.

  VQCodebookEMA    (Fix 2 — standard practice)
    Exponential Moving Average updates: embeddings track the mean of their
    assigned encoder outputs rather than being moved by backprop.
    Dead-code restart: any entry unused for a batch is reinitialised to a
    random encoder output, preventing permanent death.
    Only commitment loss is returned (VQ loss is replaced by EMA update).

  FactorizedVQCodebook   (Fix 1 — paper contribution)
    Wraps N independent VQCodebookEMA instances, one per policy dimension.
    K_i matches the number of classes for dimension i, so collapse is
    impossible by construction and each entry maps to exactly one class.
"""

from __future__ import annotations
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import List, Tuple

CODEBOOK_SIZE = 16
LATENT_DIM    = 32


# ── Baseline (gradient-based, collapse-prone) ─────────────────────────────────

class VQCodebookGrad(nn.Module):
    """Original gradient-based VQ.  Kept for ablation comparison."""

    def __init__(self, num_embeddings: int = CODEBOOK_SIZE,
                 embedding_dim: int = LATENT_DIM, beta: float = 0.25):
        super().__init__()
        self.K, self.D, self.beta = num_embeddings, embedding_dim, beta
        self.embeddings = nn.Embedding(num_embeddings, embedding_dim)
        nn.init.uniform_(self.embeddings.weight, -1 / num_embeddings, 1 / num_embeddings)
        self.register_buffer("usage_ema", torch.ones(num_embeddings) / num_embeddings)

    def forward(self, z_e: torch.Tensor):
        dist = (z_e.pow(2).sum(1, keepdim=True)
                - 2 * z_e @ self.embeddings.weight.T
                + self.embeddings.weight.pow(2).sum(1))
        code_idx = dist.argmin(1)
        e_k = self.embeddings(code_idx)
        z_q = z_e + (e_k - z_e).detach()
        loss = F.mse_loss(z_e.detach(), e_k) + self.beta * F.mse_loss(z_e, e_k.detach())
        with torch.no_grad():
            self.usage_ema = 0.99 * self.usage_ema + 0.01 * F.one_hot(code_idx, self.K).float().mean(0)
        return z_q, code_idx, loss

    def perplexity(self) -> float:
        p = self.usage_ema / self.usage_ema.sum()
        return torch.exp(-(p * (p + 1e-10).log()).sum()).item()


# ── Fix 2: EMA updates + dead-code restart ────────────────────────────────────

class VQCodebookEMA(nn.Module):
    """
    VQ codebook with Exponential Moving Average embedding updates.

    Key differences from VQCodebookGrad:
    - Embeddings are buffers (not parameters): backprop never touches them.
    - Each embedding tracks the EMA mean of z_e vectors assigned to it.
    - Dead entries (cluster_size < restart_threshold) are reinitialised to
      a random encoder output from the current batch.
    - Only β * commit_loss is returned, because the EMA replaces vq_loss.

    Reference: VQ-VAE-2, Razavi et al. 2019 (Appendix A).
    """

    def __init__(
        self,
        num_embeddings:    int   = CODEBOOK_SIZE,
        embedding_dim:     int   = LATENT_DIM,
        beta:              float = 0.25,
        decay:             float = 0.99,
        restart_threshold: float = 1.0,
    ):
        super().__init__()
        self.K                 = num_embeddings
        self.D                 = embedding_dim
        self.beta              = beta
        self.decay             = decay
        self.restart_threshold = restart_threshold

        # Embeddings stored as buffers — updated manually, not by autograd
        embed = torch.randn(num_embeddings, embedding_dim)
        self.register_buffer("embeddings",    embed.clone())
        self.register_buffer("ema_cluster_size", torch.ones(num_embeddings))
        self.register_buffer("ema_cluster_sum",  embed.clone())
        self.register_buffer("usage_ema",     torch.ones(num_embeddings) / num_embeddings)

    # ── Distance helper ───────────────────────────────────────────────────────

    def _distances(self, z_e: torch.Tensor) -> torch.Tensor:
        return (
            z_e.pow(2).sum(1, keepdim=True)      # (B,1)
            - 2 * z_e @ self.embeddings.T         # (B,K)
            + self.embeddings.pow(2).sum(1)        # (K,)
        )

    # ── EMA update (training only) ────────────────────────────────────────────

    def _ema_update(self, z_e: torch.Tensor, code_idx: torch.Tensor) -> None:
        one_hot = F.one_hot(code_idx, self.K).float()   # (B, K)
        n_batch = one_hot.sum(0)                         # (K,)
        m_batch = one_hot.T @ z_e.detach()               # (K, D)

        self.ema_cluster_size = self.decay * self.ema_cluster_size + (1 - self.decay) * n_batch
        self.ema_cluster_sum  = self.decay * self.ema_cluster_sum  + (1 - self.decay) * m_batch

        # Laplace-smoothed normalisation so no embedding blows up
        total = self.ema_cluster_size.sum()
        n_smooth = (
            (self.ema_cluster_size + 1e-5)
            / (total + self.K * 1e-5)
            * total
        )
        self.embeddings = self.ema_cluster_sum / n_smooth.unsqueeze(1)

        # Dead-code restart: reinitialise unused entries from current batch
        dead = self.ema_cluster_size < self.restart_threshold
        if dead.any():
            n_dead = int(dead.sum().item())
            rand_idx = torch.randint(0, z_e.shape[0], (n_dead,), device=z_e.device)
            self.embeddings[dead]        = z_e[rand_idx].detach()
            self.ema_cluster_size[dead]  = 1.0
            self.ema_cluster_sum[dead]   = z_e[rand_idx].detach()

        # Usage EMA for perplexity reporting
        self.usage_ema = (
            0.99 * self.usage_ema
            + 0.01 * (n_batch / max(n_batch.sum().item(), 1.0))
        )

    # ── Forward ───────────────────────────────────────────────────────────────

    def forward(
        self, z_e: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Args:  z_e  (B, D)
        Returns:
          z_q       (B, D)   quantised, straight-through gradient to z_e
          code_idx  (B,)     index of nearest embedding per sample
          loss      scalar   β * commit_loss  (EMA handles codebook update)
        """
        code_idx = self._distances(z_e).argmin(1)
        e_k      = self.embeddings[code_idx]             # (B, D)

        # Straight-through estimator
        z_q = z_e + (e_k - z_e).detach()

        # Only commitment loss — encoder learns to commit to nearest entry
        loss = self.beta * F.mse_loss(z_e, e_k.detach())

        if self.training:
            with torch.no_grad():
                self._ema_update(z_e, code_idx)

        return z_q, code_idx, loss

    def perplexity(self) -> float:
        """Effective number of codebook entries used (max = K)."""
        p = self.usage_ema / (self.usage_ema.sum() + 1e-10)
        return torch.exp(-(p * (p + 1e-10).log()).sum()).item()


# ── Fix 1: Factorized codebooks (paper contribution) ─────────────────────────

class FactorizedVQCodebook(nn.Module):
    """
    One independent VQCodebookEMA per policy dimension.

    K_i is set equal to the number of classes for dimension i:
        retry=4, timeout=3, circuit_breaker=3, fallback=4

    Because K_i == num_classes_i, each codebook entry can specialise in
    exactly one output class.  Collapse is impossible by construction.

    Compositionality: the retry dimension and the CB dimension quantise
    independently, so retry=2 can appear with any CB state.
    """

    DIM_NAMES = ["retry", "timeout", "circuit_breaker", "fallback"]

    def __init__(
        self,
        embedding_dim:  int   = LATENT_DIM,
        policy_dims:    Tuple[int, ...] = (4, 3, 3, 4),
        beta:           float = 0.25,
        decay:          float = 0.99,
        restart_threshold: float = 1.0,
    ):
        super().__init__()
        self.policy_dims = policy_dims
        self.books = nn.ModuleList([
            VQCodebookEMA(K, embedding_dim, beta, decay, restart_threshold)
            for K in policy_dims
        ])

    def forward(
        self, z_e: torch.Tensor
    ) -> Tuple[List[torch.Tensor], List[torch.Tensor], torch.Tensor]:
        """
        Returns:
          z_qs       list of (B, D)  — one quantised vector per dimension
          code_idxs  list of (B,)    — one code index per dimension
          total_vq_loss  scalar
        """
        z_qs, code_idxs, losses = [], [], []
        for book in self.books:
            z_q, idx, loss = book(z_e)
            z_qs.append(z_q)
            code_idxs.append(idx)
            losses.append(loss)
        return z_qs, code_idxs, sum(losses)

    def perplexities(self) -> List[float]:
        return [book.perplexity() for book in self.books]

    def mean_perplexity(self) -> float:
        return float(sum(self.perplexities()) / len(self.books))
