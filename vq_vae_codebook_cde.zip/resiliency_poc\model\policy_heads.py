"""
model/policy_heads.py

Four independent classification heads — one per policy dimension.
Each head maps a latent vector (z or z_q) to logits over its classes.

  RetryHead    : 4 classes  {0, 1, 2, 3}
  TimeoutHead  : 3 classes  {short, medium, long}
  CBHead       : 3 classes  {closed, half_open, open}
  FallbackHead : 4 classes  {none, alternate_node, cached_response, dead_letter}
"""

from __future__ import annotations
import torch
import torch.nn as nn
from dataclasses import dataclass

from ..label_oracle import (
    NUM_RETRY_CLASSES, NUM_TIMEOUT_CLASSES, NUM_CB_CLASSES, NUM_FALLBACK_CLASSES,
    RETRY_LABELS, TIMEOUT_LABELS, CIRCUIT_BREAKER_LABELS, FALLBACK_LABELS,
    is_valid_policy,
)

LATENT_DIM = 32


class _Head(nn.Module):
    def __init__(self, latent_dim: int, num_classes: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(latent_dim, 16),
            nn.ReLU(),
            nn.Linear(16, num_classes),
        )

    def forward(self, z: torch.Tensor) -> torch.Tensor:
        return self.net(z)


class PolicyHeads(nn.Module):
    """
    Container for all four classification heads.
    Used by both Phase-1 MLP (z from encoder) and Phase-2 VQ-VAE (z_q from codebook).
    """

    def __init__(self, latent_dim: int = LATENT_DIM):
        super().__init__()
        self.retry    = _Head(latent_dim, NUM_RETRY_CLASSES)
        self.timeout  = _Head(latent_dim, NUM_TIMEOUT_CLASSES)
        self.cb       = _Head(latent_dim, NUM_CB_CLASSES)
        self.fallback = _Head(latent_dim, NUM_FALLBACK_CLASSES)

    def forward(
        self, z: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Returns logits for each head: (retry, timeout, cb, fallback).
        """
        return (
            self.retry(z),
            self.timeout(z),
            self.cb(z),
            self.fallback(z),
        )

    def predict(self, z: torch.Tensor) -> "PolicyPrediction":
        """Argmax prediction from a single latent vector (no gradient needed)."""
        with torch.no_grad():
            r_l, t_l, c_l, f_l = self.forward(z)
            retry    = int(r_l.argmax(dim=-1).item())
            timeout  = int(t_l.argmax(dim=-1).item())
            cb       = int(c_l.argmax(dim=-1).item())
            fallback = int(f_l.argmax(dim=-1).item())
        return PolicyPrediction(retry, timeout, cb, fallback)


@dataclass
class PolicyPrediction:
    retry:    int
    timeout:  int
    cb:       int
    fallback: int
    category: int = 0   # failure category: 0=NOMINAL 1=TRANSIENT 2=PERSISTENT 3=TRANSACTION

    def is_valid(self) -> bool:
        return is_valid_policy(self.retry, self.timeout, self.cb, self.fallback)

    def describe(self) -> str:
        return (
            f"retry={RETRY_LABELS[self.retry]}, "
            f"timeout={TIMEOUT_LABELS[self.timeout]}, "
            f"CB={CIRCUIT_BREAKER_LABELS[self.cb]}, "
            f"fallback={FALLBACK_LABELS[self.fallback]}"
        )

    def as_tuple(self) -> tuple[int, int, int, int]:
        return (self.retry, self.timeout, self.cb, self.fallback)
